# Mojar Ashor
Chat App using Java Socket Programming
